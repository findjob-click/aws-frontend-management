import json
import os
import boto3
import requests
from urllib.parse import parse_qs

# Environment variables
CLIENT_ID = os.environ.get("LINKEDIN_CLIENT_ID")
CLIENT_SECRET = os.environ.get("LINKEDIN_CLIENT_SECRET")
REDIRECT_URI = os.environ.get("REDIRECT_URI")  # Optional but good practice

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('linkedin_users')


def lambda_handler(event, context):
    try:
        # Get query params
        query = event.get('queryStringParameters', {}) or {}
        code = query.get("code")
        if not code:
            return {
                "statusCode": 400,
                "body": "Missing 'code' parameter from LinkedIn."
            }

        # Exchange code for access token
        token_url = "https://www.linkedin.com/oauth/v2/accessToken"
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        token_res = requests.post(token_url, data=payload, headers=headers)
        token_data = token_res.json()

        access_token = token_data.get("access_token")
        if not access_token:
            return {
                "statusCode": 401,
                "body": f"Failed to obtain access token: {token_data}"
            }

        # Get user profile info
        profile_url = "https://api.linkedin.com/v2/me"
        email_url = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))"
        auth_headers = {"Authorization": f"Bearer {access_token}"}

        profile_res = requests.get(profile_url, headers=auth_headers).json()
        email_res = requests.get(email_url, headers=auth_headers).json()

        linkedin_id = profile_res.get("id")
        first_name = profile_res.get("localizedFirstName", "User")
        email = email_res["elements"][0]["handle~"]["emailAddress"]

        # Save user to DynamoDB
        table.put_item(Item={
            "id": linkedin_id,
            "name": first_name,
            "email": email
        })

        # Respond with welcome HTML
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "text/html"},
            "body": f"<html><body><h1>Hello {first_name}, welcome to findjob.click!</h1></body></html>"
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
